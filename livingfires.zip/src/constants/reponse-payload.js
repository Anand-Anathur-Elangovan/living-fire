export const responsePayload = {
  success: false,
  message: "",
  result: {},
};
