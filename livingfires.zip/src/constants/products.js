export const SORTBY = {
  priceLowToHigh: "priceLowToHigh",
  priceHighToLow: "priceHighToLow",
  A2Z: "A2Z",
  Z2A: "Z2A",
  oldToNew: "oldToNew",
  newToOld: "newToOld",
  bestSelling: "bestSelling",
};
